const apiUrl = 'https://self-regulate.online'; // Your API URL

// Function to display messages
function displayMessage(message, type = 'info') {
    const messageDiv = document.getElementById('message');
    if (messageDiv) {
        messageDiv.textContent = message;
        messageDiv.className = type;
    }
}

// Fetch GitHub token from chrome.storage.local
async function getGithubToken() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(['githubToken'], function (result) {
            if (result.githubToken) {
                resolve(result.githubToken);
            } else {
                reject(new Error('GitHub token not found.'));
            }
        });
    });
}

// Fetch GitHub username from chrome.storage.local
async function getGithubUsername() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(['githubUsername'], function (result) {
            if (result.githubUsername) {
                resolve(result.githubUsername);
            } else {
                reject(new Error('GitHub username not found.'));
            }
        });
    });
}

// Fetch GitHub repo from chrome.storage.local
async function getGithubRepo() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(['githubRepo'], function (result) {
            if (result.githubRepo) {
                resolve(result.githubRepo);
            } else {
                reject(new Error('GitHub repository not found.'));
            }
        });
    });
}

// Save GitHub credentials to chrome.storage.local
function saveGithubCredentials(token, username, repo) {
    chrome.storage.local.set({
        'githubToken': token,
        'githubUsername': username,
        'githubRepo': repo
    }, function () {
        displayMessage('GitHub credentials saved successfully.', 'success');
    });
}

// Fetch auth token from chrome.storage.local
async function getAuthToken() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(['authToken'], function (result) {
            if (result.authToken) {
                resolve(result.authToken);
            } else {
                reject(new Error('Auth token not found.'));
            }
        });
    });
}

// Function to truncate a string to 15 words
function truncateTo15Words(text) {
    const words = text.split(' ');
    if (words.length > 15) {
        return words.slice(0, 15).join(' ') + '...';
    }
    return text;
}

// Function to encode a string to Base64 for GitHub API
function base64EncodeUnicode(str) {
    return btoa(unescape(encodeURIComponent(str)));
}

// Function to get the SHA of a file in a GitHub repository (needed for updating files)
async function getGitHubFileSHA(filePath) {
    try {
        const githubToken = await getGithubToken();
        const githubUsername = await getGithubUsername();
        const githubRepo = await getGithubRepo();

        const response = await fetch(`https://api.github.com/repos/${githubUsername}/${githubRepo}/contents/${encodeURIComponent(filePath)}`, {
            method: 'GET',
            headers: {
                Authorization: `token ${githubToken}`,
                'Content-Type': 'application/json',
            },
        });

        if (response.status === 404) {
            // File doesn't exist, return null
            return null;
        }

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Failed to retrieve file SHA: ${errorData.message}`);
        }

        const data = await response.json();
        return data.sha; // Return the SHA for updating the file
    } catch (error) {
        console.error('Error fetching file SHA:', error);
        throw error; // Re-throw the error to be handled by the caller
    }
}

// Fetch and populate tags in the dropdown
async function fetchTags() {
    try {
        displayMessage('Loading tags...', 'info');
        const authToken = await getAuthToken();
        const response = await fetch(`${apiUrl}/api/tags`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch tags. Status: ${response.status}`);
        }

        const data = await response.json();
        const tagsSelect = document.getElementById('tags');
        if (!tagsSelect) {
            throw new Error("Element with id 'tags' not found.");
        }
        tagsSelect.innerHTML = '<option value="" disabled selected>Select a tag...</option>'; // Clear previous options

        data.tags.forEach(tag => {
            const option = document.createElement('option');
            option.value = tag.id;
            option.textContent = tag.title;
            tagsSelect.appendChild(option);
        });

        displayMessage('Tags loaded successfully.', 'success');
    } catch (error) {
        displayMessage('Error fetching tags: ' + error.message, 'error');
    }
}

// Fetch resources for the selected tag
async function fetchResources(tagId) {
    try {
        displayMessage('Loading resources...', 'info');
        const authToken = await getAuthToken();
        const response = await fetch(`${apiUrl}/api/resources`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch resources. Status: ${response.status}`);
        }

        const data = await response.json();
        const resourcesList = document.getElementById('resources-list');
        if (!resourcesList) {
            throw new Error("Element with id 'resources-list' not found.");
        }
        resourcesList.innerHTML = ''; // Clear previous content

        const resources = data.resources.filter(resource => resource.tag_id === parseInt(tagId));

        if (resources.length === 0) {
            displayMessage('No resources available for this tag.', 'info');
        }

        // Populate the resources list in the UI
        resources.forEach(resource => {
            const listItem = document.createElement('div');
            listItem.className = 'resource-item';
            const reflectionPreview = resource.reflection ? ` (${truncateTo15Words(resource.reflection)})` : '';
            listItem.textContent = `${resource.text}${reflectionPreview}`;
            resourcesList.appendChild(listItem);
        });

        const storyStatus = await fetchStoryStatus(tagId);
        const resourceSummary = document.getElementById('resource-summary');
        if (!resourceSummary) {
            throw new Error("Element with id 'resource-summary' not found.");
        }
        resourceSummary.textContent = `${resources.length} Resources Found - ${storyStatus}`;
        await displayStory(tagId, storyStatus);

        displayMessage('Resources and story loaded successfully.', 'success');
        return resources;
    } catch (error) {
        displayMessage('Error fetching resources: ' + error.message, 'error');
        return [];
    }
}

// Display the story for a selected tag
async function displayStory(tagId, storyStatus) {
    const storyPreviewDiv = document.getElementById('story-preview');
    if (!storyPreviewDiv) {
        throw new Error("Element with id 'story-preview' not found.");
    }
    storyPreviewDiv.innerHTML = '';

    if (storyStatus === 'Story Not Found') {
        storyPreviewDiv.innerHTML = `<p>No story yet... Learning in progress!</p>`;
        return;
    }

    const storyData = await fetchStoryForTag(tagId);
    if (storyData && storyData.length > 0) {
        const firstStory = storyData[0];
        storyPreviewDiv.innerHTML = `<p>${firstStory.text}</p>`;
    } else {
        storyPreviewDiv.innerHTML = `<p>No story yet... Learning in progress!</p>`;
    }
}

// Fetch the story status for a specific tag
async function fetchStoryStatus(tagId) {
    try {
        const authToken = await getAuthToken();
        const response = await fetch(`${apiUrl}/api/stories`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch stories. Status: ${response.status}`);
        }

        const data = await response.json();
        const story = data.stories.find(story => story.tag_id === parseInt(tagId));

        return story ? 'Story Found' : 'Story Not Found';
    } catch (error) {
        console.error('Error fetching story status:', error);
        return 'Story Not Found';
    }
}

// Fetch the story for a specific tag
async function fetchStoryForTag(tagId) {
    try {
        const authToken = await getAuthToken();
        const response = await fetch(`${apiUrl}/api/stories`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch stories. Status: ${response.status}`);
        }

        const data = await response.json();
        return data.stories.filter(story => story.tag_id === parseInt(tagId));
    } catch (error) {
        console.error('Error fetching story:', error);
        return [];
    }
}

// Function to export resources and story to GitHub
async function exportResourcesToGitHub(tagTitle, resources, tagId) {
    try {
        const githubToken = await getGithubToken();
        const githubUsername = await getGithubUsername();
        const githubRepo = await getGithubRepo();
        const folderPath = `${tagTitle.replace(/\s+/g, '-')}-Story`;

        for (const [index, resource] of resources.entries()) {
            const resourceName = `resource_${index + 1}.md`;
            const resourcePath = `${folderPath}/${resourceName}`;
            const resourceContent = `# ${resource.text}\n\n**Reflection**: ${resource.reflection || 'No Reflection'}\n**Created At**: ${resource.created_at || 'Unknown'}\n**Updated At**: ${resource.updated_at || 'Unknown'}\n`;

            const encodedContent = base64EncodeUnicode(resourceContent);
            const fileSHA = await getGitHubFileSHA(resourcePath);

            const payload = {
                message: `Add or update resource: ${resource.text}`,
                content: encodedContent,
                sha: fileSHA || undefined,
            };

            const response = await fetch(`https://api.github.com/repos/${githubUsername}/${githubRepo}/contents/${encodeURIComponent(resourcePath)}`, {
                method: 'PUT',
                headers: {
                    Authorization: `token ${githubToken}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`Failed to upload resource "${resource.text}": ${errorData.message}`);
            }
        }

        // Upload README.md
        const storyData = await fetchStoryForTag(tagId);
        let readmeContent = `# Story for ${tagTitle}\n\n- **Number of Resources**: ${resources.length}\n- **First Resource Created At**: ${resources[0]?.created_at || 'N/A'}\n- **Last Resource Created At**: ${resources[resources.length - 1]?.created_at || 'N/A'}\n`;

        if (storyData.length > 0) {
            readmeContent += `\n## Story:\n\n${storyData[0].text}`;
        } else {
            readmeContent += '\nNo story yet... Learning in progress!';
        }

        const encodedReadmeContent = base64EncodeUnicode(readmeContent);
        const readmeSHA = await getGitHubFileSHA(`${folderPath}/README.md`);

        const readmePayload = {
            message: `Add or update story for ${tagTitle}`,
            content: encodedReadmeContent,
            sha: readmeSHA || undefined,
        };

        const readmeResponse = await fetch(`https://api.github.com/repos/${githubUsername}/${githubRepo}/contents/${encodeURIComponent(`${folderPath}/README.md`)}`, {
            method: 'PUT',
            headers: {
                Authorization: `token ${githubToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(readmePayload),
        });

        if (!readmeResponse.ok) {
            const errorData = await readmeResponse.json();
            throw new Error(`Failed to upload README.md: ${errorData.message}`);
        }

        displayMessage('Resources and story exported successfully to GitHub!', 'success');
    } catch (error) {
        console.error('Error exporting to GitHub:', error);
        displayMessage('Error exporting to GitHub: ' + error.message, 'error');
    }
}

// Event listener for tag selection
document.getElementById('tags').addEventListener('change', async (event) => {
    const tagId = event.target.value;
    await fetchResources(tagId);
});

// Event listener for export button
document.getElementById('export-btn').addEventListener('click', async () => {
    const exportButton = document.getElementById('export-btn');
    exportButton.disabled = true;
    exportButton.textContent = 'Exporting...';

    try {
        const githubTokenInput = document.getElementById('githubTokenInput').value.trim();
        const githubUsernameInput = document.getElementById('githubUsernameInput').value.trim();
        const githubRepoInput = document.getElementById('githubRepoInput').value.trim();

        if (githubTokenInput && githubUsernameInput && githubRepoInput) {
            saveGithubCredentials(githubTokenInput, githubUsernameInput, githubRepoInput);
        } else {
            throw new Error('Please fill out all GitHub credential fields before exporting.');
        }

        const tagSelect = document.getElementById('tags');
        if (tagSelect.selectedIndex <= 0) {
            throw new Error('Please select a tag before exporting.');
        }
        const tagTitle = tagSelect.options[tagSelect.selectedIndex].text;
        const tagId = tagSelect.value;

        const resources = await fetchResources(tagId);
        if (resources.length === 0) {
            throw new Error('No resources to export for the selected tag.');
        }

        await exportResourcesToGitHub(tagTitle, resources, tagId);
    } catch (error) {
        displayMessage('Error during export: ' + error.message, 'error');
    } finally {
        exportButton.disabled = false;
        exportButton.textContent = 'Export to GitHub';
    }
});

// Add event listener to the Save Credentials button
document.getElementById('save-credentials-btn').addEventListener('click', function () {
    const saveButton = document.getElementById('save-credentials-btn');
    saveButton.disabled = true;
    saveButton.textContent = 'Saving...';

    const token = document.getElementById('githubTokenInput').value.trim();
    const username = document.getElementById('githubUsernameInput').value.trim();
    const repo = document.getElementById('githubRepoInput').value.trim();

    // Validate inputs
    let valid = true;

    if (token === '') {
        document.getElementById('githubTokenInput').classList.add('invalid');
        document.getElementById('githubTokenError').textContent = 'GitHub token is required.';
        valid = false;
    } else {
        document.getElementById('githubTokenInput').classList.remove('invalid');
        document.getElementById('githubTokenError').textContent = '';
    }

    if (username === '') {
        document.getElementById('githubUsernameInput').classList.add('invalid');
        document.getElementById('githubUsernameError').textContent = 'GitHub username is required.';
        valid = false;
    } else {
        document.getElementById('githubUsernameInput').classList.remove('invalid');
        document.getElementById('githubUsernameError').textContent = '';
    }

    if (repo === '') {
        document.getElementById('githubRepoInput').classList.add('invalid');
        document.getElementById('githubRepoError').textContent = 'GitHub repository name is required.';
        valid = false;
    } else {
        document.getElementById('githubRepoInput').classList.remove('invalid');
        document.getElementById('githubRepoError').textContent = '';
    }

    if (valid) {
        saveGithubCredentials(token, username, repo);
    } else {
        displayMessage('Please correct the highlighted fields before saving.', 'error');
    }

    saveButton.disabled = false;
    saveButton.textContent = 'Save Credentials';
});

// Function to validate GitHub credentials in real-time
function validateGithubCredentials() {
    const tokenInput = document.getElementById('githubTokenInput');
    const usernameInput = document.getElementById('githubUsernameInput');
    const repoInput = document.getElementById('githubRepoInput');

    const tokenError = document.getElementById('githubTokenError');
    const usernameError = document.getElementById('githubUsernameError');
    const repoError = document.getElementById('githubRepoError');

    tokenInput.addEventListener('input', function () {
        if (tokenInput.value.trim() === '') {
            tokenInput.classList.add('invalid');
            tokenError.textContent = 'GitHub token is required.';
        } else {
            tokenInput.classList.remove('invalid');
            tokenError.textContent = '';
        }
    });

    usernameInput.addEventListener('input', function () {
        if (usernameInput.value.trim() === '') {
            usernameInput.classList.add('invalid');
            usernameError.textContent = 'GitHub username is required.';
        } else {
            usernameInput.classList.remove('invalid');
            usernameError.textContent = '';
        }
    });

    repoInput.addEventListener('input', function () {
        if (repoInput.value.trim() === '') {
            repoInput.classList.add('invalid');
            repoError.textContent = 'GitHub repository name is required.';
        } else {
            repoInput.classList.remove('invalid');
            repoError.textContent = '';
        }
    });
}

// Call the validation function during initialization
validateGithubCredentials();

// Initialize GitHub credentials input fields
(function () {
    // Get stored GitHub credentials and populate input fields
    chrome.storage.local.get(['githubToken', 'githubUsername', 'githubRepo'], function (result) {
        if (result.githubToken) {
            document.getElementById('githubTokenInput').value = result.githubToken;
        }
        if (result.githubUsername) {
            document.getElementById('githubUsernameInput').value = result.githubUsername;
        }
        if (result.githubRepo) {
            document.getElementById('githubRepoInput').value = result.githubRepo;
        }
    });
})();

// Initial fetch of tags when the page loads
fetchTags();
