document.addEventListener('DOMContentLoaded', function () {
    const noteInput = document.getElementById('note');
    const tagSelect = document.getElementById('tag-select');
    const tagInput = document.getElementById('tag');
    const saveButton = document.getElementById('save');
    const alertBox = document.getElementById('alert');
    const stars = document.querySelectorAll('.star');
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const loginButton = document.getElementById('loginButton');
    let currentRating = 0;
    let currentTabUrl = '';
    let currentResourceId = null;  // Track if a resource exists

    // Get the current tab URL
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        currentTabUrl = tab.url;
        checkForExistingData();  // Check if data exists for this URL
    });

    // Function to update the star rating
    function updateStarColors() {
        stars.forEach((star, index) => {
            star.style.color = index < currentRating ? 'orange' : '#ccc';
        });
    }

    // Handle star click for rating
    stars.forEach((star, index) => {
        star.addEventListener('click', function () {
            currentRating = index + 1;
            updateStarColors();
        });
    });

    // Check for existing login token and load tags if logged in
    chrome.storage.local.get(['authToken'], function (result) {
        if (result.authToken) {
            loginForm.style.display = 'none';
            loadTags(result.authToken); // Load tags if logged in
        } else {
            loginForm.style.display = 'block'; // Show login form if not logged in
        }
    });

    // Handle login button click
    loginButton.addEventListener('click', function () {
        const email = emailInput.value;
        const password = passwordInput.value;

        fetch('https://self-regulate.online/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data && data.access_token) {
                chrome.storage.local.set({ authToken: data.access_token }, function () {
                    loginForm.style.display = 'none';
                    alert('Login successful!');
                    loadTags(data.access_token);
                    checkForExistingData();  // Re-check for data after login
                });
            } else {
                alert('Login failed. Please check your credentials.');
            }
        })
        .catch(error => {
            console.error('Login error:', error);
            alert('Failed to log in.');
        });
    });

    // Check if there is existing data for the current URL
    function checkForExistingData() {
        chrome.storage.local.get(['authToken'], function (result) {
            if (!result.authToken) {
                alert('Please log in to retrieve data.');
                return;
            }

            fetch(`https://self-regulate.online/api/resources?url=${encodeURIComponent(currentTabUrl)}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${result.authToken}`,
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data && data.resources && data.resources.length > 0) {
                    // Filter the resources that match the current URL and then sort them by updated_at
                    const matchingResources = data.resources.filter(resource => resource.text === currentTabUrl)
                                                            .sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
                    
                    if (matchingResources.length > 0) {
                        const mostRecentResource = matchingResources[0];

                        // Populate fields with the most recent resource that matches the current URL
                        currentResourceId = mostRecentResource.id;
                        noteInput.value = mostRecentResource.reflection || '';
                        currentRating = mostRecentResource.rating || 0;
                        updateStarColors();
                        const tagOption = Array.from(tagSelect.options).find(option => option.text === mostRecentResource.tag_title);
                        if (tagOption) {
                            tagSelect.value = tagOption.value;
                        }
                    } else {
                        currentResourceId = null;  // No matching resource found
                        noteInput.value = '';  // Clear inputs
                        tagSelect.value = '';
                        currentRating = 0;
                        updateStarColors();
                    }
                } else {
                    currentResourceId = null;  // No resource found
                    noteInput.value = '';  // Clear inputs
                    tagSelect.value = '';
                    currentRating = 0;
                    updateStarColors();
                }
            })
            .catch(error => {
                console.error('Error retrieving data:', error);
                alert('Failed to retrieve data.');
            });
        });
    }

    // Handle save button click
    saveButton.addEventListener('click', function () {
        const note = noteInput.value;
        const tag = tagInput.value || tagSelect.value;

        // Validate inputs
        if (!note || !tag || !currentRating) {
            alert('Please enter a note, tag, and rating.');
            return;
        }

        const payload = {
            text: currentTabUrl, // URL of the current tab
            reflection: note,
            tag: tag,
            rating: currentRating
        };

        chrome.storage.local.get(['authToken'], function (result) {
            if (!result.authToken) {
                alert('Please log in to save data.');
                return;
            }

            fetch('https://self-regulate.online/api/resources', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${result.authToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            })
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(result => {
                if (result.status >= 200 && result.status < 300) {
                    alertBox.style.display = 'block';
                    alertBox.textContent = 'Reflection saved!';
                    console.log('Save successful:', result.body);
                    currentResourceId = result.body.id; // Update the resource ID to the new one
                } else {
                    alert('Failed to save data.');
                    console.error('Save failed:', result.body);
                }
            })
            .catch(error => {
                console.error('Error saving data:', error);
                alert('Failed to save data.');
            });
        });
    });

    // Populate tag options (can be loaded from the API)
    function loadTags(authToken) {
        fetch('https://self-regulate.online/api/tags', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data && data.tags) {
                data.tags.forEach(tag => {
                    const option = document.createElement('option');
                    option.value = tag.title;
                    option.textContent = tag.title;
                    tagSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('Error loading tags:', error);
        });
    }
});
