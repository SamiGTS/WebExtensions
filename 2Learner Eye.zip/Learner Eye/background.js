// background.js

// Listener for messages from content scripts or popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getLearningData') {
    // Retrieve all relevant learning data from storage
    chrome.storage.local.get(
      ['lastLearningInteraction', 'lastTag', 'lastResource', 'lastStory'],
      (result) => {
        sendResponse(result);
      }
    );
    // Return true to indicate that the response will be sent asynchronously
    return true;
  } else if (request.action === 'openOptionsPage') {
    chrome.runtime.openOptionsPage();
    sendResponse({ status: 'Options page opened.' });
  }
});
