const apiUrl = 'https://self-regulate.online'; // Local API URL
let radarChartInstance;  // Store the radar chart instance globally

// Function to fetch tags
async function fetchTags(authToken) {
  const response = await fetch(`${apiUrl}/api/tags`, {
    method: 'GET',
    headers: { 'Authorization': `Bearer ${authToken}` }
  });
  return (await response.json()).tags || [];
}

// Function to fetch resources
async function fetchResources(authToken) {
  const response = await fetch(`${apiUrl}/api/resources`, {
    method: 'GET',
    headers: { 'Authorization': `Bearer ${authToken}` }
  });
  return (await response.json()).resources || [];
}

// Function to calculate the difference in days between two dates
function calculateLearningPeriod(startDate, endDate) {
  // Ensure both startDate and endDate are valid Date objects
  if (!startDate || !endDate) return 'N/A';

  const start = new Date(startDate);
  const end = new Date(endDate);

  // Handle invalid date scenarios
  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    return 'N/A';
  }

  // If both dates are the same, return 1 day minimum period
  if (start.toDateString() === end.toDateString()) {
    return 1; // Treat as at least one day of learning
  }

  // Calculate the difference in milliseconds and convert to days
  const timeDiff = Math.abs(end - start);
  return Math.ceil(timeDiff / (1000 * 60 * 60 * 24)); // Convert to days
}

// Function to count resources for each tag and calculate the longest learning period
function countResourcesForTags(tags, resources) {
  const tagResourceMap = {};

  // Initialize each tag with a resource count and date details
  tags.forEach(tag => {
    tagResourceMap[tag.id] = {
      title: tag.title,
      resourceCount: 0,
      firstResourceDate: null,
      lastResourceDate: null,
      learningPeriod: 'N/A' // Placeholder for learning period
    };
  });

  // Assign resources to each tag
  resources.forEach(resource => {
    const tagEntry = tagResourceMap[resource.tag_id];
    if (tagEntry) {
      tagEntry.resourceCount += 1;
      const resourceDate = new Date(resource.created_at);

      // Update first and last resource date for each tag
      if (!tagEntry.firstResourceDate || tagEntry.firstResourceDate > resourceDate) {
        tagEntry.firstResourceDate = resourceDate;
      }
      if (!tagEntry.lastResourceDate || tagEntry.lastResourceDate < resourceDate) {
        tagEntry.lastResourceDate = resourceDate;
      }
    }
  });

  // Calculate learning periods and convert dates to strings for display
  Object.values(tagResourceMap).forEach(tag => {
    // Calculate the learning period in days before converting dates to strings
    tag.learningPeriod = calculateLearningPeriod(tag.firstResourceDate, tag.lastResourceDate);

    // Convert the dates to strings for display after the calculation
    if (tag.firstResourceDate) tag.firstResourceDate = new Date(tag.firstResourceDate).toLocaleDateString();
    if (tag.lastResourceDate) tag.lastResourceDate = new Date(tag.lastResourceDate).toLocaleDateString();
  });

  return tagResourceMap;
}

// Function to create the radar chart
function createRadarChart(tagResourceMap) {
  const ctx = document.getElementById('resourceRadarChart').getContext('2d');
  const labels = Object.values(tagResourceMap).map(tag => tag.title);
  const data = Object.values(tagResourceMap).map(tag => tag.resourceCount);

  // Destroy existing chart instance if it exists
  if (radarChartInstance) {
    radarChartInstance.destroy();
  }

  // Create a new radar chart
  radarChartInstance = new Chart(ctx, {
    type: 'radar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Number of Resources',
        data: data,
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        borderColor: 'rgba(54, 162, 235, 1)'
      }]
    },
    options: {
      responsive: true,
      scales: {
        r: {
          beginAtZero: true
        }
      }
    }
  });
}

// Function to create the tag details table
function createTagDetailsTable(tagResourceMap) {
  const tableContainer = document.getElementById('tagDetailsTable');
  tableContainer.innerHTML = ''; // Clear existing content

  const table = document.createElement('table');
  const headers = ['Tag', 'Resource Count', 'First Resource Date', 'Last Resource Date', 'Longest Learning Period (Days)'];

  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');
  headers.forEach(header => {
    const th = document.createElement('th');
    th.textContent = header;
    headerRow.appendChild(th);
  });
  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');

  // Sort the tagResourceMap by learning period in descending order
  const sortedTags = Object.values(tagResourceMap).sort((a, b) => {
    const aPeriod = isNaN(a.learningPeriod) ? 0 : a.learningPeriod;
    const bPeriod = isNaN(b.learningPeriod) ? 0 : b.learningPeriod;
    return bPeriod - aPeriod;
  });

  // Populate the table with sorted data
  sortedTags.forEach(tag => {
    const row = document.createElement('tr');
    const tagCell = document.createElement('td');
    const countCell = document.createElement('td');
    const firstDateCell = document.createElement('td');
    const lastDateCell = document.createElement('td');
    const periodCell = document.createElement('td');

    tagCell.textContent = tag.title;
    countCell.textContent = tag.resourceCount;
    firstDateCell.textContent = tag.firstResourceDate || 'N/A';
    lastDateCell.textContent = tag.lastResourceDate || 'N/A';
    periodCell.textContent = tag.learningPeriod;

    row.appendChild(tagCell);
    row.appendChild(countCell);
    row.appendChild(firstDateCell);
    row.appendChild(lastDateCell);
    row.appendChild(periodCell);
    tbody.appendChild(row);
  });

  table.appendChild(tbody);
  tableContainer.appendChild(table);
}

// Function to set up the radar chart and tag table
async function setupRadarChartAndTable(authToken) {
  try {
    const tags = await fetchTags(authToken);
    const resources = await fetchResources(authToken);

    if (!tags.length || !resources.length) {
      document.getElementById('message').textContent = 'No tags or resources found.';
      return;
    }

    const tagResourceMap = countResourcesForTags(tags, resources);

    // Create radar chart
    createRadarChart(tagResourceMap);

    // Create the tag details table
    createTagDetailsTable(tagResourceMap);

    // Clear the loading message
    document.getElementById('message').textContent = '';
  } catch (error) {
    console.error('Error fetching or processing data:', error);
    document.getElementById('message').textContent = 'Error loading data. Please refresh or try again later.';
  }
}

// DOMContentLoaded event to initialize the app when page loads
window.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['authToken'], function (result) {
    if (result.authToken) {
      setupRadarChartAndTable(result.authToken);
    } else {
      console.error('No auth token found');
    }
  });

  // Add event listener for the refresh button
  document.getElementById('refreshBtn').addEventListener('click', () => {
    chrome.storage.local.get(['authToken'], function (result) {
      if (result.authToken) {
        setupRadarChartAndTable(result.authToken);
      } else {
        console.error('No auth token found');
      }
    });
  });

  // Show and hide the tag details table when "Show/Hide Learning Tracks" button is clicked
  document.getElementById('showTableBtn').addEventListener('click', () => {
    const tableContainer = document.getElementById('tagDetailsTable');
    const button = document.getElementById('showTableBtn');

    if (tableContainer.style.display === 'none' || tableContainer.style.display === '') {
      tableContainer.style.display = 'block';
      button.textContent = 'Hide Learning Tracks';
    } else {
      tableContainer.style.display = 'none';
      button.textContent = 'Show Learning Tracks';
    }
  });
});
