document.addEventListener('DOMContentLoaded', function () {
  const apiUrl = 'https://self-regulate.online'; // Your API URL
  const loginSection = document.getElementById('login-section');
  const infoSection = document.getElementById('info-section');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const loginButton = document.getElementById('loginButton');
  const alertBox = document.getElementById('alert');
  const lastInteractionEl = document.getElementById('last-interaction');
  const lastTagEl = document.getElementById('last-tag');
  const lastResourceEl = document.getElementById('last-resource');
  const lastStoryEl = document.getElementById('last-story');
  const optionsLink = document.getElementById('optionsLink');

  // Set default message for login
  alertBox.textContent = 'Please log in.';
  alertBox.style.display = 'block';

  async function login(email, password) {
    try {
      const response = await fetch(`${apiUrl}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (data && data.access_token) {
        chrome.storage.local.set({ authToken: data.access_token }, function () {
          alertBox.style.display = 'none'; // Hide the alert once logged in
          loginSection.style.display = 'none';
          infoSection.style.display = 'block';
          loadLearningInfo(); // Load learning info once logged in
        });
      } else {
        alertBox.textContent = 'Invalid login. Please try again.';
        alertBox.style.display = 'block';
      }
    } catch (error) {
      alertBox.textContent = 'Failed to log in. Please try again.';
      alertBox.style.display = 'block';
    }
  }

  // Helper function to display time ago
  function timeAgo(date) {
    const now = new Date();
    const past = new Date(date);
    const diffMs = now - past;
    const diffMinutes = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays} day(s) ago`;
    if (diffHours > 0) return `${diffHours} hour(s) ago`;
    if (diffMinutes > 0) return `${diffMinutes} minute(s) ago`;
    return 'just now';
  }

  // Fetch data from API
  async function fetchData(endpoint, authToken) {
    const response = await fetch(`${apiUrl}${endpoint}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch data from ${endpoint}`);
    }

    return await response.json();
  }

  async function loadLearningInfo() {
    chrome.storage.local.get(['authToken'], async function (result) {
      if (!result.authToken) {
        loginSection.style.display = 'block';
        infoSection.style.display = 'none';
        return;
      }

      try {
        const [tagData, resourceData, storyData] = await Promise.all([
          fetchData('/api/tags', result.authToken),
          fetchData('/api/resources', result.authToken),
          fetchData('/api/stories', result.authToken) // Fetch stories
        ]);

        const lastTag = tagData.tags.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0] || { title: 'No Tags Found', created_at: null };
        const lastResource = resourceData.resources.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0] || { text: 'No Resources Found', created_at: null };
        const lastStory = storyData.stories.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0] || { text: 'No Stories Found', created_at: null };

        const recentInteraction = new Date(Math.max(
          new Date(lastTag.created_at || 0),
          new Date(lastResource.created_at || 0),
          new Date(lastStory.created_at || 0)
        ));

        // Update UI with the last interaction details
        lastInteractionEl.textContent = `It has been ${timeAgo(recentInteraction)} since your last learning interaction.`;


       // lastTagEl.textContent = `${lastTag.title} (${timeAgo(lastTag.created_at)})`;

       // lastResourceEl.textContent = `${lastResource.text} (${timeAgo(lastResource.created_at)})`;

       // Handle last tag display
if (lastTag && lastTag.created_at) {
  lastTagEl.textContent = `${lastTag.title} (${timeAgo(new Date(lastTag.created_at))})`;
} else {
  lastTagEl.textContent = 'No tag has been created yet.';
}

// Handle last resource display
if (lastResource && lastResource.created_at) {
  lastResourceEl.textContent = `${lastResource.text}  ${lastResource.reflection}  (${timeAgo(new Date(lastResource.created_at))})`;

  // lastResourceEl.textContent = `${lastResource.reflection} (${timeAgo(new Date(lastResource.created_at))})`;
} else {
  lastResourceEl.textContent = 'No resource has been created yet.';
}




        // Update UI with only the time of the last story creation
        if (lastStory && lastStory.created_at) {
          // If there is a valid last story with a created_at timestamp
          lastStoryEl.textContent = `${timeAgo(new Date(lastStory.created_at))}`;
      } else {
          // If no story exists or created_at is null
          lastStoryEl.textContent = 'No story has been created yet.';
      }
      

 
        // Store all fetched data in chrome.storage.local for content scripts
        chrome.storage.local.set({
          lastLearningInteraction: recentInteraction.toISOString(),
          lastTag: lastTag,
          lastResource: lastResource,
          lastStory: lastStory // Store the last story
        }, function () {
          console.log('Learning data stored successfully.');
        });

      } catch (error) {
        console.error('Error fetching learning info:', error);
        alertBox.textContent = 'Error fetching learning data.';
        alertBox.style.display = 'block';
      }
    });
  }

  // Automatically load the info if already authenticated
  chrome.storage.local.get(['authToken'], function (result) {
    if (result.authToken) {
      loginSection.style.display = 'none';
      infoSection.style.display = 'block';
      loadLearningInfo();
    }
  });

  // Handle login button click
  loginButton.addEventListener('click', function () {
    const email = emailInput.value;
    const password = passwordInput.value;
    login(email, password);
  });

  // Open the Options page when clicking the link
  optionsLink.addEventListener('click', function (e) {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
});
