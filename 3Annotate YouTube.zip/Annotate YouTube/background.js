// Listen for tab updates to detect YouTube videos
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && tab.url.includes('youtube.com/watch')) {
        // Set badge with "Y" when on a YouTube video
        chrome.action.setBadgeText({ text: 'Y', tabId: tabId });
        chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });  // Red background for badge
    } else if (tab.url && !tab.url.includes('youtube.com/watch')) {
        // Clear the badge when leaving YouTube
        chrome.action.setBadgeText({ text: '', tabId: tabId });
    }
});

// Ensure badge stays when switching between YouTube tabs
chrome.tabs.onActivated.addListener(function(activeInfo) {
    chrome.tabs.get(activeInfo.tabId, function(tab) {
        if (tab.url.includes('youtube.com/watch')) {
            chrome.action.setBadgeText({ text: 'Y', tabId: activeInfo.tabId });
            chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });
        } else {
            chrome.action.setBadgeText({ text: '', tabId: activeInfo.tabId });
        }
    });
});
