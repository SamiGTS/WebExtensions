// Extract YouTube video ID from the active tab
function getYouTubeVideoId(url) {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
    const matches = url.match(regex);
    return matches ? matches[1] : null;
}

// Open the annotation page when the button is clicked
document.getElementById('annotate-button').addEventListener('click', function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const activeTab = tabs[0];
        const videoId = getYouTubeVideoId(activeTab.url);

        if (videoId) {
            // Open the GitHub page for annotation with the video ID
            const annotateUrl = `https://self-regulate.online/YouTube/?videoId=${videoId}`;
            //       const annotateUrl = `https://samincl.github.io/FrameStory/?videoId=${videoId}`;

            chrome.tabs.create({ url: annotateUrl });
        } else {
            alert('I cannos see the Video , Are you on YouTube?');
        }
    });
});
