// content_script.js

// Function to format "time ago"
function timeAgo(date) {
  const now = new Date();
  const diffMs = now - date;
  const diffMinutes = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffDays > 0) return `${diffDays} day(s) ago`;
  if (diffHours > 0) return `${diffHours} hour(s) ago`;
  if (diffMinutes > 0) return `${diffMinutes} minute(s) ago`;
  return 'just now';
}

// Function to detect which social media platform we are on
function detectSocialMediaPlatform() {
  const hostname = window.location.hostname;

  if (hostname.includes("facebook.com")) {
    return "Facebook";
  } else if (hostname.includes("twitter.com") || hostname.includes("x.com")) {
    return "Twitter";
  } else if (hostname.includes("linkedin.com")) {
    return "LinkedIn";
  } else if (hostname.includes("instagram.com")) {
    return "Instagram";
  } else if (hostname.includes("pinterest.com")) {
    return "Pinterest";
  } else if (hostname.includes("tiktok.com")) {
    return "TikTok";
  } else if (hostname.includes("reddit.com")) {
    return "Reddit";
  } else if (hostname.includes("youtube.com")) {
    return "YouTube";
  }

  return "Unknown Platform";
}

// Function to modify the story for a specific platform using OpenAI's chat endpoint
async function modifyStoryForPlatform(apiKey, storyText, platform, totalParts = 3) {
  const model = 'gpt-3.5-turbo'; // Use 'gpt-4' if you have access

  let systemPrompt = '';
  let userPrompt = '';

  // Adjust the prompt based on the platform
  switch (platform) {
    case 'Facebook':
      systemPrompt = `You are a skilled writer helping a programming learner share their experiences on Facebook. Facebook posts should be engaging, personal, and encourage interaction.`;
      userPrompt = `Please modify the following story for posting on Facebook. Structure the story into ${totalParts} parts, labeled as 1/${totalParts}, 2/${totalParts}, ..., up to ${totalParts}/${totalParts}. Each part should be engaging and encourage comments or shares. Here's the text: "${storyText}"`;
      break;
    case 'Twitter':
      systemPrompt = `You are a skilled writer helping a programming learner share their experiences on Twitter. Tweets should be concise, engaging, and may include relevant hashtags.`;
      userPrompt = `Please modify the following story for posting on Twitter. Structure the story into a thread of ${totalParts} tweets, labeled as 1/${totalParts}, 2/${totalParts}, ..., up to ${totalParts}/${totalParts}. Each tweet should be within 280 characters, engaging, and may include hashtags. Here's the text: "${storyText}"`;
      break;
    case 'LinkedIn':
      systemPrompt = `You are a skilled writer helping a programming learner share their experiences on LinkedIn. LinkedIn posts should be professional, insightful, and encourage networking.`;
      userPrompt = `Please modify the following story for posting on LinkedIn. Structure the story into ${totalParts} parts, labeled as Part 1, Part 2, ..., up to Part ${totalParts}. Each part should be professional, insightful, and encourage engagement. Here's the text: "${storyText}"`;
      break;
    case 'Instagram':
      systemPrompt = `You are a skilled writer helping a programming learner share their experiences on Instagram. Instagram captions should be engaging, use emojis, and encourage likes and comments.`;
      userPrompt = `Please modify the following story for posting on Instagram. Structure the story into ${totalParts} captions, labeled as 1/${totalParts}, 2/${totalParts}, ..., up to ${totalParts}/${totalParts}. Each caption should be engaging, may use emojis, and encourage interaction. Here's the text: "${storyText}"`;
      break;
    case 'Reddit':
      systemPrompt = `You are a skilled writer helping a programming learner share their experiences on Reddit. Reddit posts should be informative, engaging, and appropriate for the subreddit.`;
      userPrompt = `Please modify the following story for posting on Reddit. Structure the story into ${totalParts} posts, labeled as Part 1, Part 2, ..., up to Part ${totalParts}. Each part should be informative, engaging, and encourage discussion. Here's the text: "${storyText}"`;
      break;
    case 'YouTube':
      systemPrompt = `You are a skilled scriptwriter helping a programming learner share their experiences on YouTube. Scripts should be engaging, clear, and suitable for video narration.`;
      userPrompt = `Please modify the following story into a script suitable for a YouTube video. Structure the script into ${totalParts} sections, labeled as Section 1, Section 2, ..., up to Section ${totalParts}. Each section should be engaging and flow naturally. Here's the text: "${storyText}"`;
      break;
    default:
      systemPrompt = `You are a skilled writer helping a programming learner share their experiences on social media. The posts should be engaging and appropriate for the platform.`;
      userPrompt = `Please modify the following story for posting on social media. Structure the story into ${totalParts} parts, labeled as 1/${totalParts}, 2/${totalParts}, ..., up to ${totalParts}/${totalParts}. Each part should be engaging and flow naturally. Here's the text: "${storyText}"`;
      break;
  }

  const messages = [
    {
      role: "system",
      content: systemPrompt
    },
    {
      role: "user",
      content: userPrompt
    }
  ];

  try {
    const response = await fetchWithTimeout('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: model,
        messages: messages,
        max_tokens: 1000,  // Adjust the token limit as needed
      }),
      mode: 'cors',
      timeout: 10000, // 10 seconds timeout
    });

    if (!response.ok) {
      const errorData = await response.json();
      const errorMessage = errorData.error ? errorData.error.message : response.statusText;
      throw new Error(`OpenAI API Error: ${errorMessage}`);
    }

    const result = await response.json();
    return result.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error during story modification:', error.message);
    throw new Error('Failed to modify the story. Please check your API key and network connection.');
  }
}

// Function to fetch with timeout
async function fetchWithTimeout(resource, options = {}) {
  const { timeout = 10000 } = options;

  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(resource, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    if (error.name === 'AbortError') {
      throw new Error('Request timed out');
    }
    throw error;
  }
}

// Function to create and display the modal
function createAndShowModal(data) {
  // Check if modal already exists to prevent duplicates
  if (document.getElementById('learning-modal-overlay')) {
    return;
  }

  // Create modal overlay
  const modalOverlay = document.createElement('div');
  modalOverlay.id = 'learning-modal-overlay';

  // Create modal content container
  const modalContent = document.createElement('div');
  modalContent.id = 'learning-modal-content';

  // Close button
  const closeButton = document.createElement('button');
  closeButton.id = 'closeButton';
  closeButton.innerHTML = '&times;';

  // Dynamic Modal Title based on last interaction
  const modalTitle = document.createElement('h3');
  modalTitle.id = 'dynamicModalTitle';
  if (data.lastLearningInteraction) {
    const lastDate = new Date(data.lastLearningInteraction);
    modalTitle.textContent = `It has been ${timeAgo(lastDate)} since your last learning interaction.`;
  } else {
    modalTitle.textContent = 'No learning interactions recorded.';
  }

  // Create table container
  const tableContainer = document.createElement('div');
  tableContainer.className = 'table-container';

  // Create table
  const infoTable = document.createElement('table');
  infoTable.className = 'info-table';

  // Table body
  const tbody = document.createElement('tbody');

  // Helper function to add a row
  function addRow(label, value) {
    const tr = document.createElement('tr');

    const tdLabel = document.createElement('td');
    tdLabel.className = 'label-cell';
    tdLabel.textContent = label;

    const tdValue = document.createElement('td');
    tdValue.className = 'value-cell';
    tdValue.innerHTML = value;

    tr.appendChild(tdLabel);
    tr.appendChild(tdValue);
    tbody.appendChild(tr);
  }

  // Last tag message
  if (data.lastTag && data.lastTag.title) {
    const lastTagDate = new Date(data.lastTag.created_at);
    addRow(
      'Last Tag Created:',
      `<span>${data.lastTag.title} (${timeAgo(lastTagDate)})</span>`
    );
  } else {
    addRow('Last Tag Created:', '<span>No tags created yet.</span>');
  }

  // Last resource message (clickable link if valid)
  if (data.lastResource && data.lastResource.text) {
    let resourceContent = '';
    if (data.lastResource.url && data.lastResource.url.startsWith('http')) {
      resourceContent = `<a href="${data.lastResource.url}" target="_blank">${data.lastResource.text}</a>`;
    } else {
      resourceContent = `${data.lastResource.text}`;
    }
    const resourceDate = new Date(data.lastResource.created_at);
    addRow(
      'Last Resource Added:',
      `<span>${resourceContent} (${timeAgo(resourceDate)})</span>`
    );
  } else {
    addRow('Last Resource Added:', '<span>No resources added yet.</span>');
  }

  // Last story creation time
  if (data.lastStory && data.lastStory.created_at) {
    const lastStoryDate = new Date(data.lastStory.created_at);
    addRow(
      'Last Story Created:',
      `<span>${timeAgo(lastStoryDate)}</span>`
    );
  } else {
    addRow('Last Story Created:', '<span>No stories created yet.</span>');
  }

  // Append tbody to table
  infoTable.appendChild(tbody);
  tableContainer.appendChild(infoTable);

  // Share Last Story Button
  const shareStoryButton = document.createElement('button');
  shareStoryButton.className = 'modal-button';
  shareStoryButton.id = 'shareStoryButton';
  shareStoryButton.textContent = 'Copy Last Story';

  // Add the collapsible section for timer settings
  const toggleButton = document.createElement('button');
  toggleButton.textContent = 'Toggle Timer Settings';
  toggleButton.className = 'modal-button';
  toggleButton.style.marginTop = '20px';

  // Create the expandable section
  const expandableSection = document.createElement('div');
  expandableSection.id = 'expandableSection';
  expandableSection.style.display = 'none'; // Hidden initially

  // Timer settings
  const timerInputLabel = document.createElement('label');
  timerInputLabel.textContent = 'Set timer (minutes): ';
  timerInputLabel.className = 'modal-label';

  const timerInput = document.createElement('input');
  timerInput.type = 'number';
  timerInput.min = 1;
  timerInput.value = localStorage.getItem('timer_minutes') || 15;
  timerInput.className = 'modal-input';

  // Blackout message settings
  const messageInputLabel = document.createElement('label');
  messageInputLabel.textContent = 'Custom Blackout Message: ';
  messageInputLabel.className = 'modal-label';

  const messageInput = document.createElement('input');
  messageInput.type = 'text';
  messageInput.value = localStorage.getItem('blackout_message') || 'Time to do something else';
  messageInput.className = 'modal-input';

  // Save settings button
  const saveSettingsButton = document.createElement('button');
  saveSettingsButton.textContent = 'Save Settings';
  saveSettingsButton.className = 'modal-button';
  saveSettingsButton.style.marginTop = '15px';

  // Append all timer-related elements to the expandable section
  expandableSection.appendChild(timerInputLabel);
  expandableSection.appendChild(timerInput);
  expandableSection.appendChild(messageInputLabel);
  expandableSection.appendChild(messageInput);
  expandableSection.appendChild(saveSettingsButton);

  // Event listener for toggle button
  toggleButton.addEventListener('click', () => {
    if (expandableSection.style.display === 'none') {
      expandableSection.style.display = 'block';
    } else {
      expandableSection.style.display = 'none';
    }
  });

  // Feedback message
  const feedbackDiv = document.createElement('div');
  feedbackDiv.id = 'feedbackMessage';
  feedbackDiv.style.textAlign = 'center';
  feedbackDiv.style.display = 'none'; // Hidden by default

  // Append elements to modal content
  modalContent.appendChild(closeButton);
  modalContent.appendChild(modalTitle);
  modalContent.appendChild(tableContainer);
  modalContent.appendChild(shareStoryButton);
  modalContent.appendChild(toggleButton);  // Add the toggle button
  modalContent.appendChild(expandableSection);  // Add the expandable section
  modalContent.appendChild(feedbackDiv);

  // Append modal content to overlay
  modalOverlay.appendChild(modalContent);

  // Append styles
  const style = document.createElement('style');
  style.textContent = `
    /* Modal Overlay Styling */
    #learning-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(15, 15, 15, 0.75);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
      animation: fadeIn 0.3s ease;
    }

    /* Modal Content Styling */
    #learning-modal-content {
      background-color: #ffffff;
      padding: 35px 25px;
      border-radius: 12px;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      position: relative;
      animation: slideDown 0.3s ease;
    }

    /* Dynamic Modal Title */
    #dynamicModalTitle {
      margin-top: 0;
      color: #2c3e50;
      font-size: 1.8rem;
      text-align: center;
      font-weight: 700;
      margin-bottom: 25px;
      word-wrap: break-word;
    }

    /* Table Styling */
    .table-container {
      overflow-x: auto;
    }

    .info-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 25px;
    }

    .info-table th,
    .info-table td {
      padding: 12px 15px;
      text-align: left;
    }

    .info-table th {
      background-color: #f5f5f5;
      color: #34495e;
      width: 35%;
      font-weight: 600;
      border-bottom: 2px solid #ddd;
    }

    .info-table td {
      color: #555;
      border-bottom: 1px solid #eee;
    }

    .info-table tr:nth-child(even) td {
      background-color: #fafafa;
    }

    .info-table a {
      color: #1e90ff;
      text-decoration: none;
    }

    .info-table a:hover {
      text-decoration: underline;
    }

    /* Button Styling */
    .modal-button {
      display: block;
      width: 100%;
      padding: 14px;
      background-color: #1e90ff;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      text-align: center;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .modal-button:hover {
      background-color: #1c86ee;
      transform: translateY(-2px);
    }

    /* Modal Input and Label Styling */
    .modal-label {
      font-weight: 600;
      color: #2c3e50;
      font-size: 1.1rem;
      margin-top: 10px;
      margin-bottom: 5px;
      display: block;
    }

    .modal-input {
      width: 100%;
      padding: 12px;
      font-size: 1rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin-bottom: 15px;
      background-color: #f9f9f9;
      color: #333;
    }

    /* Close Button */
    #closeButton {
      position: absolute;
      top: 15px;
      right: 15px;
      background: none;
      border: none;
      font-size: 1.8rem;
      color: #999;
      cursor: pointer;
      transition: color 0.3s ease;
    }

    #closeButton:hover {
      color: #666;
    }

    /* Feedback Message Styling */
    #feedbackMessage {
      margin-top: 15px;
      font-size: 1rem;
      color: #28a745; /* Default success message color */
      text-align: center;
      display: none; /* Hidden by default */
    }

    /* Animations */
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideDown {
      from { transform: translateY(-20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    /* Responsive */
    @media (max-width: 600px) {
      #learning-modal-content {
        padding: 30px 20px;
      }

      #dynamicModalTitle {
        font-size: 1.6rem;
      }

      .info-table th,
      .info-table td {
        padding: 10px 12px;
      }

      .modal-button {
        padding: 12px;
        font-size: 1rem;
      }
    }
  `;
  document.head.appendChild(style);

  // Append modal overlay to body
  document.body.appendChild(modalOverlay);

  // Event Listener for Close Button
  closeButton.addEventListener('click', () => {
    document.body.removeChild(modalOverlay);
  });

  // Event Listener for Share Story Button
  shareStoryButton.addEventListener('click', async () => {
    console.log('Share Story button clicked');
    if (shareStoryButton.disabled) {
      console.log('Button is disabled, click ignored');
      return;
    }
    shareStoryButton.disabled = true;
    shareStoryButton.textContent = 'Please wait...';

    if (data.lastStory && data.lastStory.text) {
      const originalStory = data.lastStory.text;
      const platform = detectSocialMediaPlatform();

      feedbackDiv.textContent = 'Modifying story...';
      feedbackDiv.style.color = '#000'; // Set to black for processing message
      feedbackDiv.style.display = 'block';

      try {
        const apiKey = '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'; // Replace with your actual API key

        console.log('Sending request to modify story');
        const modifiedStory = await modifyStoryForPlatform(apiKey, originalStory, platform);
        console.log('Received modified story:', modifiedStory);

        // Copy the modified story to clipboard
        await navigator.clipboard.writeText(modifiedStory);

        // Update feedbackDiv to show success message
        feedbackDiv.textContent = `Story modified for ${platform} and copied to clipboard!`;
        feedbackDiv.style.color = '#28a745'; // Set success message color
        feedbackDiv.style.display = 'block';
        console.log('Story copied to clipboard');
      } catch (error) {
        console.error('Error modifying story:', error.message);
        feedbackDiv.style.display = 'block';
        feedbackDiv.style.color = 'red';
        feedbackDiv.textContent = `Failed to modify story: ${error.message}`;

        // Provide option to copy the original story as-is
        const copyOriginalButton = document.createElement('button');
        copyOriginalButton.className = 'modal-button';
        copyOriginalButton.textContent = 'Copy Original Story';
        copyOriginalButton.style.marginTop = '15px';
        copyOriginalButton.addEventListener('click', async () => {
          try {
            await navigator.clipboard.writeText(originalStory);
            feedbackDiv.textContent = 'Original story copied to clipboard!';
            feedbackDiv.style.color = '#28a745';
            copyOriginalButton.remove();  // Remove the button after copying
            console.log('Original story copied to clipboard');
          } catch (err) {
            feedbackDiv.style.color = 'red';
            feedbackDiv.textContent = 'Failed to copy original story.';
            console.error('Failed to copy original story:', err);
          }
        });
        modalContent.appendChild(copyOriginalButton);
      } finally {
        shareStoryButton.disabled = false;
        shareStoryButton.textContent = 'Copy Last Story';
        console.log('Button re-enabled');
      }
    } else {
      feedbackDiv.style.display = 'block';
      feedbackDiv.style.color = 'red';
      feedbackDiv.textContent = 'No story to share.';
      shareStoryButton.disabled = false;
      shareStoryButton.textContent = 'Copy Last Story';
      console.log('No story to share');
    }
  });

  // Save settings to localStorage and update the timer and blackout message
  saveSettingsButton.addEventListener('click', () => {
    const timerMinutes = parseInt(timerInput.value, 10);
    const blackoutMessage = messageInput.value;

    localStorage.setItem('timer_minutes', timerMinutes);
    localStorage.setItem('blackout_message', blackoutMessage);

    feedbackDiv.textContent = 'Settings saved!';
    feedbackDiv.style.color = '#28a745';
    feedbackDiv.style.display = 'block';
  });
}

// Function to request learning data from background.js
function requestLearningDataAndShowModal() {
  chrome.runtime.sendMessage({ action: 'getLearningData' }, (response) => {
    if (chrome.runtime.lastError) {
      console.error('Error fetching learning data:', chrome.runtime.lastError);
      return;
    }

    // Only show the modal if there's at least one learning interaction
    if (
      response.lastLearningInteraction ||
      (response.lastTag && response.lastTag.title) ||
      (response.lastResource && response.lastResource.text) ||
      (response.lastStory && response.lastStory.created_at)
    ) {
      createAndShowModal(response);
    }
  });
}

// Time tracking feature for social media pages
let timerInterval;
const timerMinutes = parseInt(localStorage.getItem('timer_minutes'), 10) || 15;  // Use saved timer setting or default to 15 minutes
let timeRemaining = timerMinutes * 60; // Convert minutes to seconds for countdown

// Create and style the timer display
const timerDisplay = document.createElement('div');
timerDisplay.style.position = 'fixed';
timerDisplay.style.bottom = '10px';
timerDisplay.style.right = '10px';
timerDisplay.style.padding = '10px';
timerDisplay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
timerDisplay.style.color = 'white';
timerDisplay.style.fontSize = '1.2rem';
timerDisplay.style.zIndex = '9999';
timerDisplay.style.borderRadius = '5px';
document.body.appendChild(timerDisplay);

// Function to format time in mm:ss
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Function to update the timer display
function updateTimer() {
  timeRemaining--;
  timerDisplay.innerHTML = `Time left: ${formatTime(timeRemaining)}`;

  if (timeRemaining <= 0) {
    clearInterval(timerInterval);
    blackoutPage();
  }
}

// Start the timer when the page loads
timerInterval = setInterval(updateTimer, 1000);

// Function to blackout the page after time limit is reached
function blackoutPage() {
  // Get the custom blackout message from localStorage
  const blackoutMessage = localStorage.getItem('blackout_message') || 'Time to do something else';

  // Create blackout overlay
  const blackoutOverlay = document.createElement('div');
  blackoutOverlay.style.position = 'fixed';
  blackoutOverlay.style.top = '0';
  blackoutOverlay.style.left = '0';
  blackoutOverlay.style.width = '100%';
  blackoutOverlay.style.height = '100%';
  blackoutOverlay.style.backgroundColor = 'black';
  blackoutOverlay.style.zIndex = '10000';
  blackoutOverlay.style.display = 'flex';
  blackoutOverlay.style.alignItems = 'center';
  blackoutOverlay.style.justifyContent = 'center';
  blackoutOverlay.style.color = 'white';
  blackoutOverlay.style.fontSize = '3rem';
  blackoutOverlay.innerHTML = blackoutMessage;

  // Append overlay to body
  document.body.appendChild(blackoutOverlay);
}

// Ensure the script runs after the DOM is fully loaded
window.addEventListener('load', function () {
  requestLearningDataAndShowModal();
});
